/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package zombiekiller;

/**
 *
 * @author Nadia Visser
 */
public class Zombie {

    public String name;
    public int age;
    public int killing;

   
    public Zombie(String name, int age, int killing ) {
        this.name = name;
        this.age = age;
        this.killing = killing;
        
    }

}
