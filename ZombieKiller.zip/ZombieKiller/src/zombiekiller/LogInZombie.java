/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package zombiekiller;

import static com.sun.glass.ui.Cursor.setVisible;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;

/**
 *
 * @author Nadia Visser
 */
public class LogInZombie {

    public static void main(String[] args) {

        // Creating instances of JFrame    
        JFrame frame = new JFrame("My First swing Example");
        // Setting the width and height of frame
        frame.setSize(350, 200);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        // Creating a JPanel
        JPanel panel = new JPanel();
        // Adding panel to frame
        frame.add(panel);
        placeComponents(panel);

    }

    private static void placeComponents(JPanel panel) {
        panel.setLayout(null);

        // Creating JLabel
        JLabel userLabel = new JLabel("User");
        // Specifing the location aand size of component
        userLabel.setBounds(10, 20, 80, 25);
        panel.add(userLabel);

        // Creating text field what the user is going to use to enter their username
        JTextField userText = new JTextField(20);
        userText.setBounds(10, 20, 80, 25);
        panel.add(userText);

        // Creating password field what the user is going to use to enter their password
        JLabel passwordLabel = new JLabel("Password");
        passwordLabel.setBounds(10, 50, 80, 25);
        panel.add(passwordLabel);

        // Displays dots to protect the password like we normally see on login screens.
        JPasswordField passwordText = new JPasswordField(20);
        passwordText.setBounds(100, 50, 165, 25);
        panel.add(passwordText);

        // Creating a log in button
        JButton loginButton = new JButton("Log in");
        loginButton.setBounds(10, 80, 80, 25);
        panel.add(loginButton);

        JLabel message = new JLabel();
        panel.add(message);

        // Adding a listener to components
        loginButton.addActionListener(new ActionListenrt(){
            
            )};
        
        setVisible(true);
    }

}
