package zombiekiller;

import java.util.ArrayList;
import java.util.Scanner;

public class ZombieKiller {

    ArrayList<Zombie> listZombie = new ArrayList<>();
    public int zombieDistance;
    private final Scanner scanner = new Scanner(System.in);

    public static void main(String[] args) {

        ZombieKiller kill = new ZombieKiller();
        kill.run();
    }

    public ZombieKiller() {
    }

    public void run() {

        System.out.println("Welcome to zombie killer program!");
        System.out.println(" ");

        String backpack[] = {"Shotgun", "Rifle", "Knife", "Sniper mode"};
        String zombies[] = {"Close- range zombie", "Mid-range zombie", "Long distance zombie"};

        System.out.println("Backpack items: ");
        System.out.println(backpack[0]);
        System.out.println(backpack[1]);
        System.out.println(backpack[2]);
        System.out.println(backpack[3]);
        int zombiePoints = 0;

        boolean allZombiesIsNotDead = true;
        while (allZombiesIsNotDead) {
            System.out.println("");
            System.out.println("Please enter the distance the zombie is from you");

            int zombieDistance = getOption(zombies);
            int zombieChoice = zombieDistance;
            allZombiesIsNotDead = false;

            switch (zombieChoice) {
                case 1:
                    System.out.println("Make use of " + backpack[2] + " in backpack: ");
                    System.out.println(backpack[2] + " Activated....");

                    boolean yesOrNo2 = getConfirm("Is all the zombies dead? ");
                    if (yesOrNo2) {

                        Zombie zombieInfo = getZombieInfo();
                        zombiePoints++;

                    } else {
                        System.out.println("Beter luck next time");

                    }

                    break;
                case 2:
                    System.out.println("Make use of " + backpack[1] + " in backpack: ");
                    System.out.println(backpack[1] + " Activated...");

                    boolean answer1 = getConfirm("Is zombies dead?");
                    if (answer1) {

                        Zombie zombieInfo = getZombieInfo();
                        zombiePoints++;
                    } else {

                        System.out.println("Beter luck next time");
                        break;
                    }
                    break;
                default:

                    System.out.println("Make use of " + backpack[0] + " and " + backpack[3] + " in backpack: ");
                    System.out.println(backpack[0]);
                    System.out.println(backpack[3]);

                    boolean answer2 = getConfirm("Is all the zombies dead? ");
                    if (answer2) {

                        Zombie zombieInfo = getZombieInfo();
                        zombiePoints++;

                    } else {
                        System.out.println("Beter luck next time");
                    }
                    break;
            }

            boolean confirmDeadZombies = true;
            while (confirmDeadZombies) {

                boolean yesOrNo = getConfirm("Is all the zombies dead yet? ");
                if (yesOrNo) {

                    System.out.println("Yayy Congrats on killing dead people!");
                    confirmDeadZombies = false;
                    allZombiesIsNotDead = false;
                } else {
                    System.out.println("");
                    System.out.println("Please enter the distance the zombie is from you");
                    System.out.println("1. " + zombies[0]);
                    System.out.println("2. " + zombies[1]);
                    System.out.println("3. " + zombies[2]);

                    int zombieDistance2 = getOption();

                    switch (zombieDistance2) {
                        case 1:
                            System.out.println("Make use of " + backpack[2] + " in backpack: ");
                            System.out.println(backpack[2] + " activated...");

                            boolean yesOrNo2 = getConfirm("Is zombie dead?");
                            if (yesOrNo2) {

                                Zombie zombieInfo = getZombieInfo();
                                zombiePoints++;
                                break;
                            } else {
                                System.out.println("Beter luck next time");

                            }
                            break;
                        case 2:
                            System.out.println("Make use of " + backpack[1] + " in backpack: ");
                            System.out.println(backpack[1] + " activated...");

                            boolean yesOrNo3 = getConfirm("Is zombie dead?");
                            if (yesOrNo3) {

                                Zombie zombieInfo = getZombieInfo();
                                zombiePoints++;
                                break;
                            } else {
                                System.out.println("Beter luck next time");

                            }
                            break;
                        case 3:

                            System.out.println("Make use of " + backpack[0] + " and " + backpack[3] + " in backpack: ");
                            System.out.println(backpack[0] + " activated...");
                            System.out.println(backpack[3] + " activated...");

                            boolean yesOrNo4 = getConfirm("Is zombie dead?");
                            if (yesOrNo4) {

                                Zombie zombieInfo = getZombieInfo();
                                zombiePoints++;

                            } else {
                                System.out.println("Beter luck next time");
                                break;
                            }
                            break;

                    }
                }
                break;
            }

        }
        System.out.println("Zombie total is: " + zombiePoints);

    }

    public boolean getConfirm(String question) {

        System.out.println(question);
        System.out.println("1. Yes");
        System.out.println("2. No");

        int confirm = Integer.parseInt(scanner.nextLine());
        System.out.println(" ");
        return confirm == 1;
    }

    public Zombie getZombieInfo() {
        System.out.println("Congrats to human kind!");
        System.out.println(" ");
        System.out.println("Please enter zombies name:");
        String name = scanner.nextLine();
        System.out.println("");
        System.out.println("Please enter zombies age: ");
        int age = Integer.parseInt(scanner.nextLine());
        System.out.println("");
        System.out.println("How did you kill the zombie?");
        System.out.println("1. With a shotgun and sniper mode activated");
        System.out.println("2. With a knife");
        System.out.println("3. With rifle");
        int killing = Integer.parseInt(scanner.nextLine());
        Zombie zombieInfo = null;
        zombieInfo = new Zombie(name, age, killing);
        listZombie.add(zombieInfo);
        return zombieInfo;

    }

    public int getOption(String array[]) {

        for (int i = 0; i < array.length; i++) {

            System.out.println((i + 1) + ". " + array[i]);

        }

        return getOption();

    }

    public int getOption() {
        System.out.print("PLease enter option: ");
        int option = Integer.parseInt(scanner.nextLine());
        System.out.println(" ");
        return option;

    }

    public void zombieDistance2() {
        int zombieDistance2 = 0;
        if (zombieDistance2 < 1 && zombieDistance2 > 4) {
        } else {
            throw new IllegalArgumentException("Invalid animalOption input");
        }
    }

    public String yesOrNo() {
        int yesOrNo = 0;
        if (yesOrNo < 1 && yesOrNo > 2) {
        } else {
            throw new IllegalArgumentException("Invalid animalOption input");
        }
        return null;
    }

    public void zombieDistance() {
        int zombieDistance = 0;
        if (zombieDistance < 1 && zombieDistance > 4) {
            throw new IllegalArgumentException("Invalid animalOption input");
        }
    }
}
